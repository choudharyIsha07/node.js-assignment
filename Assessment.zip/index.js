const express = require("express");
const path = require("path");
const app = express();

const PORT = 8080;

app.use(express.static(path.join(__dirname, "path")));

app.listen(PORT, () => console.log(`Server running on ${PORT}`));

app.get("/introduction", (req, res) => {
  res.send(`
    <html>
      <head>
        <link rel="stylesheet" type="text/css" href="/index.css">
      </head>
      <body>
        <div class="container">
          <p class="introduction-text">
            My self isha Choudhary and I am From burhanpur(M.P).I pursing my B.Tech from Shri vaishnav Vidhyapeeth vishwavidhyalay,Indore(M.P).I scored an 8.34 CGPA in my previous semester.About my Technical skills,I am skilled in ReactJS and NodeJS and have a good knowledge of ui/ux design.i am also interested in software testing. About my hobbies,my hobbys is cooking,reading books,dancing.That's all about me.
          </p>
        </div>
      </body>
    </html>
  `);
});
